<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Eligibility Check</title>
    <style>
        /* Add some basic styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        p {
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Donor Eligibility Check</h2>
        <p>Welcome, <?php echo $_SESSION['username']; ?>! Please answer the following questions to determine if you're eligible to donate blood.</p>
        <form method="POST" action="verify_process.php">
            <div class="form-group">
                <label>Age (Must be between 18 and 65):</label>
                <input type="number" name="age" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Weight (kg):</label>
                <input type="number" name="weight" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Have you had any major surgery or illness in the last 6 months?</label>
                <select name="recent_surgery" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Do you have any chronic health conditions (HIV, Hepatitis, etc.)?</label>
                <select name="chronic_condition" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Are you currently taking any medications?</label>
                <select name="medications" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Have you traveled to a malaria-endemic area in the past 12 months?</label>
                <select name="recent_travel" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Are you pregnant or have you been pregnant in the last 6 months? (if applicable)</label>
                <select name="pregnant" class="form-control">
                    <option value="Not Applicable">Not Applicable</option>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Do you have a hemoglobin level above 12.5 g/dL?</label>
                <select name="hemoglobin" class="form-control" required>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
            </div>
            <div class="form-group">
                <label>Have you consumed alcohol or used drugs in the last 24 hours?</label>
                <select name="alcohol_drugs" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <div class="form-group">
                <label>Have you had any tattoos or piercings in the last 6-12 months?</label>
                <select name="tattoo_piercing" class="form-control" required>
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                </select>
            </div>
            <button type="submit" class="btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>

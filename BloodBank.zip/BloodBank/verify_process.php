<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bloodbank"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $age = $_POST['age'];
    $weight = $_POST['weight'];
    $recent_surgery = $_POST['recent_surgery'];
    $chronic_condition = $_POST['chronic_condition'];
    $medications = $_POST['medications'];
    $recent_travel = $_POST['recent_travel'];
    $pregnant = $_POST['pregnant'];
    $hemoglobin = $_POST['hemoglobin'];
    $alcohol_drugs = $_POST['alcohol_drugs'];
    $tattoo_piercing = $_POST['tattoo_piercing'];

    // Basic eligibility criteria
    if ($age < 18 || $age > 65) {
        echo "You are not eligible to donate blood due to age restrictions.";
    } elseif ($weight < 50) {
        echo "You must weigh at least 50kg to donate blood.";
    } elseif ($recent_surgery == "Yes" || $chronic_condition == "Yes" || $medications == "Yes" || $recent_travel == "Yes" || $pregnant == "Yes" || $hemoglobin == "No" || $alcohol_drugs == "Yes" || $tattoo_piercing == "Yes") {
        echo "You are not eligible to donate blood based on your responses.";
    } else {
        echo "Thank you! You are eligible to donate blood.";
    }

    // Close the database connection
    $conn->close();
}
?>
